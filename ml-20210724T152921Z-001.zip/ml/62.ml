do
  print "Hello, world!"
end
