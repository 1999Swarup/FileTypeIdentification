type 'a t = 'a list constraint 'a = [< `X]
