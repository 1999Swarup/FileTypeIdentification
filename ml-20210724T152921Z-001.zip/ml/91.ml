let () =
  Api.reg_mod "Packed1_client";
  print_endline Packed1.mykey
