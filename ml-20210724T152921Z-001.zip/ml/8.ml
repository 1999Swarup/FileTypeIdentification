
let _ = do f 2 where f x = x * x
