
type t = {
  trace : int;
  tandy : bool;
  cheat : bool;
  no_buffer : bool;
  no_line_wrap : bool;
  hide_unimplemented : bool;
}
