(** Unit test for Algodiff module matrix oeprations, Dense Ndarray in Core *)


include Unit_algodiff_matrix_generic.Make (Owl.Dense.Ndarray.D)
