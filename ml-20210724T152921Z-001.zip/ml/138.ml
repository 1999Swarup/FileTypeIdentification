type t = P11_ulong.t
let typ = Ctypes.ulong
