let register s f = print_endline (s^": registering"); f ()
