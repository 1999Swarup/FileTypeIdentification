(*s: yacc/lalr.ml *)
(*e: yacc/lalr.ml *)
