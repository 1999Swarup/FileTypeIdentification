external print_module : unit -> unit = "print_module"

let () = print_module ()
