
(* -f *)
let debug_line = ref false
(* -e *)
let debug_inclusion = ref false
(* -m *)
let debug_macros = ref false
