let say_hello () = Printf.printf "Hello from vendored lib!\n"
