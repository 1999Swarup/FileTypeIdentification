#use "sem_static_exceptions.ml";;
let sem_exp = sem_static;;
#use "parser/run.ml";;
