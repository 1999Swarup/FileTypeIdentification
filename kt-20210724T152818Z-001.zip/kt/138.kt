package br.com.lucasalbuquerque.domain

open class Summary() {
    var resourceURI: String? = null
    var name: String? = null
}