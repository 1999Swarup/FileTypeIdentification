package xyz.hisname.fireflyiii.repository.models.rules

data class RelationshipsX(
        val user: User
)