package io.github.droidkaigi.confsched2018.presentation.common.fragment

interface Findable {
    val tagForFinding: String
}
