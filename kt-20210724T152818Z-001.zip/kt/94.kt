package com.youtubedl.di.qualifier

import javax.inject.Qualifier

/**
 * Created by cuongpm on 12/8/18.
 */

@Qualifier
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
annotation class RemoteData