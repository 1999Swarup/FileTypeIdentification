package xyz.hisname.fireflyiii.repository.models.rules

data class Links(
        val self: String,
        val first: String,
        val last: String
)