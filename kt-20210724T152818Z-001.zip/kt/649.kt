package mp

actual fun multiPlatformFunction() = "This is the JavaScript-specific implementation"
