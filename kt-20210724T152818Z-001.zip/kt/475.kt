package io.oversec.one.crypto.images.xcoder

import java.io.IOException

class ContentNotFullyEmbeddedException : IOException()
