package com.mrpowergamerbr.loritta.parallax.wrappers

class ParallaxMessageOptions(
		val attachment: ParallaxAttachment
)